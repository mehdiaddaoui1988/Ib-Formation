﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuPenduMetier
{
    public enum EtatPartieEnum
    {
        Pas_Commencee, En_Cours, Gagnee, Perdue
    }
}
